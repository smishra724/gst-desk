/* "Tally & GST work" tab: pull books from TallyPrime, then registers, GSTR-1 JSON,
   GSTR-3B working and reconciliations with GSTR-2B / GSTR-1. */
(function () {
  'use strict';
  const G = window.GSTR, W = window.GSTWork, App = window.GSTApp;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const esc = App.esc;
  const inr = (n) => (+n || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const SETTINGS = 'gstf_work';

  const st = {
    clientId: '', company: '', port: 9000, from: '', to: '',
    docs: null, status: '', error: '', companies: [],
    twoB: null, twoBFiles: [], r1: null, r1File: '',
    recon2b: null, reconR1: null, gstr1: null, tolerance: 1
  };
  (function defaults() {
    const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - 1);
    const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0');
    st.from = `${y}-${m}`; st.to = `${y}-${m}`;
  })();

  const client = () => App.profiles.find(p => p.id === st.clientId) || null;
  // Company names compared loosely: "Travel-O-Media Solutions Pvt Ltd" = "TRAVEL O MEDIA SOLUTIONS PRIVATE LIMITED"
  const norm = (s) => String(s || '').toUpperCase().replace(/\bPRIVATE\b/g, 'PVT').replace(/\bLIMITED\b/g, 'LTD').replace(/\(.*?\)/g, '').replace(/[^A-Z0-9]/g, '').replace(/^M\/?S/, '');
  const namesOf = (p) => [p.tally.company, p.nickname, p.partA.legalName, p.business.tradeName].filter(Boolean).map(norm);
  // Loose similarity for suggestions ("Azelock Laser" ~ "AZELOCK LASER PRIVATE LIMITED")
  const STOP = new Set(['PVT', 'PRIVATE', 'LTD', 'LIMITED', 'LLP', 'CO', 'COMPANY', 'MS', 'THE', 'AND', 'OF', 'INDIA', 'OPC']);
  const toks = (s) => String(s || '').toUpperCase().replace(/[^A-Z0-9 ]+/g, ' ').split(/\s+/).filter(t => t && !STOP.has(t));
  const sim = (a, b) => { const x = toks(a), y = new Set(toks(b)); if (!x.length || !y.size) return 0; const hit = x.filter(t => y.has(t)).length; return hit / Math.max(x.length, y.size) + (x[0] && y.has(x[0]) ? 0.25 : 0); };
  const score = (p, company) => Math.max(...[p.nickname, p.partA.legalName, p.business.tradeName].filter(Boolean).map(n => sim(company, n)), 0);
  const clientFor = (company) => App.profiles.find(p => p.tally.company === company && score(p, company) >= 0.35) || App.profiles.find(p => [p.nickname, p.partA.legalName, p.business.tradeName].filter(Boolean).map(norm).includes(norm(company))) || App.profiles.find(p => p.tally.company === company) || null;
  const monthEnd = (ym) => { const [y, m] = ym.split('-').map(Number); return `${ym}-${String(new Date(y, m, 0).getDate()).padStart(2, '0')}`; };
  const fileBase = () => `${(client() ? G.displayName(client()) : st.company || 'client').replace(/[\\/:*?"<>|]+/g, ' ').trim()}_${st.from}${st.to !== st.from ? '_to_' + st.to : ''}`;

  async function loadSettings() {
    const s = (await chrome.storage.local.get(SETTINGS))[SETTINGS] || {};
    st.port = s.port || 9000;
    st.tolerance = s.tolerance ?? 1;
    if (s.clientId && App.profiles.some(p => p.id === s.clientId)) st.clientId = s.clientId;
    else if (App.profiles[0]) st.clientId = App.profiles[0].id;
    const c = client(); st.company = (c && c.tally.company) || '';
  }
  const saveSettings = () => chrome.storage.local.set({ [SETTINGS]: { port: st.port, clientId: st.clientId, tolerance: st.tolerance } });

  function sums(kind) {
    const L = (st.docs || []).filter(d => !d.cancelled && d.kind === kind);
    return L.reduce((a, d) => { a.n++; a.txval += d.txval; a.tax += d.igst + d.cgst + d.sgst + d.cess; return a; }, { n: 0, txval: 0, tax: 0 });
  }

  // Tally company not linked to a client: link it to an existing client (best matches first), add it, or fetch it from CA Desk
  function linkBox() {
    const linkable = App.profiles.filter(p => !p.tally.company || !st.companies.includes(p.tally.company) || p.tally.company === st.company)
      .map(p => ({ p, s: score(p, st.company) })).sort((a, b) => b.s - a.s || G.displayName(a.p).localeCompare(G.displayName(b.p)));
    const best = linkable[0] && linkable[0].s >= 0.5 ? linkable[0].p : null;
    return `<div class="note warn" style="margin-top:10px">
      <div><b>“${esc(st.company)}”</b> is open in Tally but not linked to a GST Desk client.${best ? ` It looks like <b>${esc(G.displayName(best))}</b>.` : ''}</div>
      ${linkable.length ? `<div class="row" style="gap:8px;margin-top:8px;flex-wrap:wrap;align-items:center">
        <select id="w-linkto" style="max-width:420px">${linkable.map(({ p, s }) => `<option value="${p.id}"${p === best ? ' selected' : ''}>${esc(G.displayName(p))}${p.gstin ? ' · ' + esc(p.gstin) : ''}${s >= 0.5 ? ' (suggested)' : ''}</option>`).join('')}${best ? '' : '<option value="" selected>— Choose the client —</option>'}</select>
        <button class="primary" id="w-link">Link to this client</button></div>` : ''}
      <div class="small" style="margin-top:8px">Not in the list? <button class="link" id="w-fromca">Get it from CA Desk</button> (sends it with its GSTIN and GST login) · <button class="link" id="w-addclient">Add as a new client</button>. Reading from Tally works without linking.</div>
    </div>`;
  }
  function linkTo(id) {
    const p = App.profiles.find(x => x.id === id); if (!p) return;
    p.tally.company = st.company; App.saveProfiles();
    st.clientId = p.id; saveSettings();
    App.toast(`Linked “${st.company}” to ${G.displayName(p)}`);
    render();
  }

  function clientOptions() {
    const open = st.companies.map(n => ({ n, p: clientFor(n) }));
    const openIds = new Set(open.filter(x => x.p).map(x => x.p.id));
    const opt = (v, label, sel) => `<option value="${esc(v)}"${sel ? ' selected' : ''}>${esc(label)}</option>`;
    const cl = (p) => opt(p.id, G.displayName(p) + (p.gstin ? ' · ' + p.gstin : ''), p.id === st.clientId);
    const inTally = open.map(x => x.p ? opt(x.p.id, `${G.displayName(x.p)}${x.p.gstin ? ' · ' + x.p.gstin : ''}`, x.p.id === st.clientId)
      : opt('tally:' + x.n, `${x.n} (not a client yet)`, !st.clientId && st.company === x.n)).join('');
    const rest = App.profiles.filter(p => !openIds.has(p.id)).map(cl).join('');
    return (!st.clientId && !st.company ? '<option value="" selected>— Choose a client or a company open in Tally —</option>' : '') +
      (inTally ? `<optgroup label="Open in Tally now">${inTally}</optgroup>` : '') +
      (rest ? `<optgroup label="${inTally ? 'Other GST Desk clients' : 'GST Desk clients'}">${rest}</optgroup>` : '') +
      (!inTally && !rest ? '<option value="" disabled>No clients yet – click “List open companies”</option>' : '');
  }

  function render() {
    const root = $('#work');
    const c = client();
    const single = st.from === st.to;
    const flags = (st.docs || []).filter(d => d.flags && d.flags.length).length;
    root.innerHTML = `
      <h2>Tally &amp; GST work</h2>
      <p class="lead">Reads sales, purchases and notes straight from TallyPrime, then builds registers, the GSTR-1 JSON, the GSTR-3B working and reconciliations with GSTR-2B and GSTR-1.</p>

      <section class="card"><header><h3>1 · Read from Tally</h3><span class="hint">TallyPrime must be open with the company loaded</span></header><div class="body">
        <div class="grid">
          <div class="f s4"><label for="w-client">Client / Tally company</label><select id="w-client">${clientOptions()}</select></div>
          <div class="f s4"><label for="w-company">Company in Tally</label><input id="w-company" type="text" list="w-companies" value="${esc(st.company)}" placeholder="Exactly as in TallyPrime">
            <datalist id="w-companies">${st.companies.map(n => `<option value="${esc(n)}">`).join('')}</datalist></div>
          <div class="f s2"><label for="w-port">ODBC / server port</label><input id="w-port" type="text" inputmode="numeric" value="${esc(st.port)}"></div>
          <div class="f s2"><span class="lbl">&nbsp;</span><button id="w-list">List open companies</button></div>
          <div class="f s3"><label for="w-from">From month</label><input id="w-from" type="month" value="${st.from}"></div>
          <div class="f s3"><label for="w-to">To month</label><input id="w-to" type="month" value="${st.to}"></div>
          <div class="f s3"><span class="lbl">&nbsp;</span><button class="primary" id="w-fetch">Read from Tally</button></div>
        </div>
        ${!c && st.company ? linkBox() : ''}
        ${c && st.company && score(c, st.company) < 0.35 ? `<div class="note warn" style="margin-top:10px"><b>Check the company:</b> client is <b>${esc(G.displayName(c))}</b> but “Company in Tally” is <b>${esc(st.company)}</b>. ${st.companies.length ? `Read from: <select id="w-pickco">${['', ...st.companies].map(n => `<option value="${esc(n)}"${n === st.company ? ' selected' : ''}>${n ? esc(n) : '— choose —'}</option>`).join('')}</select>` : 'Type the right company name, or click “List open companies”.'}</div>`
          : c && st.company && c.tally.company && norm(c.tally.company) !== norm(st.company) ? `<div class="note warn" style="margin-top:10px">${esc(G.displayName(c))} is linked to Tally company “${esc(c.tally.company)}”, but you are reading “${esc(st.company)}”. <button class="link" id="w-relink">Link it to “${esc(st.company)}” instead</button></div>` : ''}
        ${c && !c.gstin ? '<div class="note warn" style="margin-top:10px">This client has no GSTIN saved – add it on the Clients tab (needed for GSTR-1 and place-of-supply).</div>' : ''}
        ${st.status ? `<div class="note" style="margin-top:10px">${esc(st.status)}${st.raw ? ' <button class="link" id="w-raw" title="Saves exactly what Tally sent, to share if something is not picked up">Save Tally reply (for support)</button>' : ''}</div>` : ''}
        ${st.error ? `<div class="note err" style="margin-top:10px">${esc(st.error)}<br><span class="small">In TallyPrime: F1 (Help) → Settings → Connectivity → Client/Server configuration → TallyPrime acts as <b>Both</b>, Enable ODBC <b>Yes</b>, Port <b>${esc(st.port)}</b>. Restart Tally after changing.</span></div>` : ''}
        ${st.docs ? `<div class="stats" style="margin-top:12px">
          ${[['Sales', 'sales'], ['Credit notes', 'credit'], ['Purchases', 'purchase'], ['Debit notes', 'debit']].map(([l, k]) => { const s = sums(k); return `<div class="stat"><div class="k">${l}</div><div class="v">${s.n}</div><div class="s">Taxable ₹${inr(s.txval)} · Tax ₹${inr(s.tax)}</div></div>`; }).join('')}
          <div class="stat"><div class="k">Needs a look</div><div class="v">${flags}</div><div class="s">vouchers with warnings</div></div>
        </div>
        <div class="row" style="margin-top:12px"><button id="w-reg">Export sales &amp; purchase registers (Excel)</button></div>` : ''}
      </div></section>

      ${st.docs ? `
      <div class="cols">
        <section class="card"><header><h3>2 · GSTR-1 JSON</h3><span class="hint">from Tally sales</span></header><div class="body">
          ${single ? `<p class="small" style="margin-top:0">Builds B2B, B2CL, B2CS, CDNR, HSN (B2B/B2C) and documents issued for ${esc(st.from)}. Exports/SEZ are listed for you to add. Check it in the GST offline tool or upload on the portal.</p>
            <div class="row"><button class="primary" id="w-r1">Build GSTR-1 JSON</button>${st.gstr1 ? '<button id="w-r1dl">Download JSON</button><button id="w-r1x">Exceptions (Excel)</button>' : ''}</div>
            ${st.gstr1 ? `<div class="row" style="margin-top:8px;align-items:center;gap:8px;flex-wrap:wrap"><select id="w-g1ret"><option value="GSTR1">GSTR-1 (monthly / quarterly)</option><option value="IFF">IFF (QRMP, months 1–2)</option></select>
              <button class="primary" id="w-g1up">⬆ Upload to GST portal (autopilot)</button>
              <span class="small muted">Logs in with the saved GST ID and password (you type the CAPTCHA), opens the return, uploads this JSON and generates the summary. Filing (DSC/EVC) stays with you.</span></div>` : ''}
            ${st.gstr1 ? gstr1Html() : ''}` : '<p class="muted small">Choose a single month (From = To) to build GSTR-1.</p>'}
        </div></section>

        <section class="card"><header><h3>3 · GSTR-2B reconciliation</h3><span class="hint">Tally purchases vs 2B</span></header><div class="body">
          <div class="drop" id="w-2b-drop"><b>Choose GSTR-2B JSON file(s)</b> or drop them here<br><span class="small muted">${st.twoBFiles.length ? esc(st.twoBFiles.join(', ')) : 'One file per month – from Download returns'}</span></div>
          <input type="file" id="w-2b" accept=".json,application/json" multiple hidden>
          <div class="row" style="margin-top:10px"><label class="small">Tolerance ₹ <input id="w-tol" type="text" inputmode="decimal" value="${esc(st.tolerance)}" style="width:60px;min-height:28px;padding:3px 6px"></label>
            <button class="primary" id="w-rec2b"${st.twoB ? '' : ' disabled'}>Reconcile</button>${st.recon2b ? '<button id="w-rec2bx">Download (Excel)</button>' : ''}</div>
          ${st.recon2b ? reconHtml(st.recon2b, 'purchase') : ''}
        </div></section>
      </div>

      <div class="cols">
        <section class="card"><header><h3>4 · GSTR-3B working</h3><span class="hint">books + 2B</span></header><div class="body">
          <p class="small" style="margin-top:0">Outward tax from Tally (3.1, 3.2) and ITC from GSTR-2B (4A), with books-vs-2B ITC. ${st.twoB ? '' : '<b>Load GSTR-2B</b> above for the ITC tables.'}</p>
          <div class="row"><button class="primary" id="w-3b">Show GSTR-3B working</button>${st.threeB ? '<button id="w-3bx">Download (Excel)</button>' : ''}</div>
          ${st.threeB ? threeBHtml() : ''}
        </div></section>

        <section class="card"><header><h3>5 · GSTR-1 reconciliation</h3><span class="hint">Tally sales vs filed GSTR-1</span></header><div class="body">
          <div class="drop" id="w-r1-drop"><b>Choose GSTR-1 JSON</b> downloaded from the portal<br><span class="small muted">${st.r1File ? esc(st.r1File) : 'Compares B2B, B2CL and credit notes invoice-wise; B2CS in total'}</span></div>
          <input type="file" id="w-r1f" accept=".json,application/json" hidden>
          <div class="row" style="margin-top:10px"><button class="primary" id="w-recr1"${st.r1 ? '' : ' disabled'}>Reconcile</button>${st.reconR1 ? '<button id="w-recr1x">Download (Excel)</button>' : ''}</div>
          ${st.reconR1 ? reconHtml(st.reconR1, 'sales') : ''}
        </div></section>
      </div>` : ''}`;
    wire();
  }

  function gstr1Html() {
    const j = st.gstr1.json;
    const cnt = (k) => (j[k] || []).reduce((a, x) => a + ((x.inv || x.nt || [x]).length), 0);
    const ex = st.gstr1.exceptions;
    return `<table class="tbl" style="margin-top:10px"><tbody>
      <tr><td>B2B invoices</td><td class="n">${cnt('b2b')}</td></tr><tr><td>B2CL invoices</td><td class="n">${cnt('b2cl')}</td></tr>
      <tr><td>Export invoices (6A EXP${(j.exp || []).length ? ': ' + (j.exp || []).map(e => `${e.exp_typ === 'WPAY' ? 'with IGST' : 'under LUT'} ${e.inv.length}`).join(', ') : ''})</td><td class="n">${cnt('exp')}</td></tr>
      <tr><td>Credit/debit notes (unregistered / export)</td><td class="n">${(j.cdnur || []).length}</td></tr>
      <tr><td>B2CS rows</td><td class="n">${(j.b2cs || []).length}</td></tr><tr><td>Credit/debit notes (registered)</td><td class="n">${cnt('cdnr')}</td></tr>
      <tr><td>HSN rows (B2B / B2C)</td><td class="n">${j.hsn.hsn_b2b.length} / ${j.hsn.hsn_b2c.length}</td></tr>
      <tr class="sum"><td>Net taxable value</td><td class="n">₹${inr(st.gstr1.totals.txval)}</td></tr></tbody></table>
      ${ex.length ? `<div class="note warn" style="margin-top:10px">${ex.length} item${ex.length > 1 ? 's' : ''} need your attention:<ul style="margin:6px 0 0;padding-left:18px">${ex.slice(0, 8).map(e => `<li>${esc(e.doc.number || '')} ${esc(e.doc.party || '')}: ${esc(e.msg)}</li>`).join('')}${ex.length > 8 ? `<li>…and ${ex.length - 8} more (see Excel)</li>` : ''}</ul></div>` : '<div class="note" style="margin-top:10px">No exceptions.</div>'}`;
  }

  function reconHtml(res, side) {
    const order = ['Matched', 'Value mismatch', 'GSTIN differs', 'Only in books', 'Only in books (not in GSTR-1)', 'Only in 2B', 'Only in GSTR-1'];
    const cls = (k) => k === 'Matched' ? 'ok' : /mismatch|differs/.test(k) ? 'warn' : 'err';
    const rows = Object.entries(res.summary).sort((a, b) => order.indexOf(a[0]) - order.indexOf(b[0]));
    const issues = res.rows.filter(r => r.status !== 'Matched').slice(0, 12);
    return `<table class="tbl" style="margin-top:10px"><thead><tr><th>Status</th><th class="n">Docs</th><th class="n">Tax (books)</th><th class="n">Tax (${side === 'purchase' ? '2B' : 'GSTR-1'})</th></tr></thead><tbody>
      ${rows.map(([k, v]) => `<tr><td><span class="st ${cls(k)}">${esc(k)}</span></td><td class="n">${v.count}</td><td class="n">${inr(v.booksTax)}</td><td class="n">${inr(v.portalTax)}</td></tr>`).join('')}
      </tbody></table>
      ${side === 'sales' && st.r1 && st.r1.b2cs ? `<p class="small" style="margin:8px 0 0">B2CS in GSTR-1: taxable ₹${inr(st.r1.b2cs.txval)}, tax ₹${inr(st.r1.b2cs.igst + st.r1.b2cs.cgst + st.r1.b2cs.sgst)} · Books (unregistered sales, net): taxable ₹${inr(b2csBooks().txval)}, tax ₹${inr(b2csBooks().tax)}</p>` : ''}
      ${issues.length ? `<div class="tbl-wrap" style="margin-top:10px;max-height:260px"><table class="tbl"><thead><tr><th>Status</th><th>Party</th><th>Invoice</th><th class="n">Tax diff</th></tr></thead><tbody>
        ${issues.map(r => { const b = r.b || {}, p = r.p || {}; const d = (r.b ? b.igst + b.cgst + b.sgst : 0) - (r.p ? p.igst + p.cgst + p.sgst : 0);
          return `<tr><td><span class="st ${cls(r.status)}">${esc(r.status)}</span></td><td>${esc(b.name || p.name || b.gstin || p.gstin || '')}</td><td>${esc(b.num || p.num || '')}</td><td class="n">${inr(d)}</td></tr>`; }).join('')}
      </tbody></table></div>${res.rows.filter(r => r.status !== 'Matched').length > 12 ? '<p class="muted small">Full list in the Excel download.</p>' : ''}` : ''}`;
  }
  function b2csBooks() {
    const L = (st.docs || []).filter(d => !d.cancelled && !d.gstin && !d.export && (d.kind === 'sales' || d.kind === 'credit'));
    const own = ((client() || {}).gstin || '').slice(0, 2);
    return L.filter(d => !(d.kind === 'sales' && d.pos !== own && d.total > 100000)).reduce((a, d) => {
      const s = d.kind === 'credit' ? -1 : 1; a.txval += s * d.txval; a.tax += s * (d.igst + d.cgst + d.sgst); return a;
    }, { txval: 0, tax: 0 });
  }

  function threeBHtml() {
    const w = st.threeB;
    const r = (l, a) => a ? `<tr><td>${l}</td><td class="n">${inr(a.txval)}</td><td class="n">${inr(a.igst)}</td><td class="n">${inr(a.cgst)}</td><td class="n">${inr(a.sgst)}</td><td class="n">${inr(a.cess)}</td></tr>` : '';
    return `<div class="tbl-wrap" style="margin-top:10px"><table class="tbl"><thead><tr><th>Table</th><th class="n">Taxable</th><th class="n">IGST</th><th class="n">CGST</th><th class="n">SGST</th><th class="n">Cess</th></tr></thead><tbody>
      ${r('3.1(a) Outward taxable', w.a)}${r('3.1(b) Zero rated', w.b)}${r('3.1(c) Nil / exempt', w.c)}${r('3.1(d) Inward RCM', w.d)}
      ${st.twoB ? r('4A(1) Imports (2B)', w.itc.imports) + r('4A(3) RCM (books)', w.booksRcm) + r('4A(4) ISD (2B)', w.itc.isd) + r('4A(5) All other ITC (2B)', w.itc.other) + r('Not available as per 2B', w.itc.notAvail) : ''}
      ${r('ITC as per books', w.booksItc)}
      </tbody></table></div>
      ${Object.keys(w.inter).length ? `<p class="small" style="margin:8px 0 0">3.2 inter-state to unregistered: ${Object.entries(w.inter).map(([k, v]) => `${esc(G.stateName(k) || k)} ₹${inr(v.txval)}`).join(' · ')}</p>` : ''}`;
  }

  /* ---------- actions ---------- */
  async function fetchTally() {
    const c = client();
    if (!st.company) { st.error = 'Type the company name exactly as it appears in TallyPrime (or use “List open companies”).'; return render(); }
    if (st.from > st.to) { st.error = '“From” month is after “To” month.'; return render(); }
    st.error = ''; st.status = 'Connecting to Tally…'; st.docs = null; st.gstr1 = null; st.recon2b = null; st.reconR1 = null; st.threeB = null;
    render();
    try {
      const t = GSTTally.Tally(st.port);
      const stats = { seen: 0, skipped: {} };
      const topts = { ownStateCode: (c && c.gstin || '').slice(0, 2), stats };
      st.raw = null;
      st.docs = await t.documents(st.company, `${st.from}-01`, monthEnd(st.to), topts,
        (msg) => { st.status = msg; const n = $('#work .note'); if (n) n.textContent = msg; });
      const live = st.docs.filter(d => !d.cancelled), ex = live.filter(d => d.export && d.kind === 'sales').length;
      const other = Object.entries(stats.skipped).filter(([t]) => !/^(receipt|payment|contra|journal|memorandum|reversing journal|physical stock|stock journal|delivery note|receipt note|rejections? (in|out)|sales order|purchase order|job work.*|material (in|out)|attendance|payroll)$/i.test(t));
      st.status = `Read ${live.length} GST vouchers from “${st.company}” (${st.from} to ${st.to})${ex ? ` – including ${ex} export/SEZ invoice${ex > 1 ? 's' : ''}` : ''}. Tally sent ${stats.seen} vouchers in all.` +
        (other.length ? ` Not read as sales/purchase: ${other.map(([t, n]) => `“${t}” (${n})`).join(', ')} – tell GST Desk if one of these is a sales or purchase type.` : '') +
        (!stats.seen ? ' Tally sent no vouchers for these months – check the From/To months and that the company has entries in that period.' : '') +
        (stats.seen && !live.length ? ` No sales or purchases are entered in “${st.company}” for this period – Tally only has: ${Object.entries(stats.skipped).map(([t, n]) => `${t} (${n})`).join(', ')}. Check that this is the right company and month.` : '');
      st.raw = topts.raw || null;
      // link the client to this Tally company only if it had none and the names look alike (never silently re-link)
      if (c && !c.tally.company && score(c, st.company) >= 0.5) { c.tally.company = st.company; App.saveProfiles(); }
    } catch (e) { st.error = e.message; st.status = ''; }
    render();
  }

  async function listCompanies(quiet) {
    if (!quiet) { st.error = ''; st.status = 'Asking Tally for open companies…'; render(); }
    try {
      st.companies = await GSTTally.Tally(st.port).companies();
      st.status = st.companies.length ? `Open in Tally: ${st.companies.join(', ')} – pick one in “Client / Tally company”.` : 'Tally is reachable but no company is open.';
      // link GST Desk clients to their Tally company by name
      let linked = 0;
      for (const n of st.companies) { const p = clientFor(n); if (p && !p.tally.company) { p.tally.company = n; linked++; } }
      if (linked) App.saveProfiles();
      const c = client();
      if (c && !st.company) st.company = c.tally.company || '';
      if (!c && !st.company && st.companies.length) {   // nothing chosen yet: take the first open company
        const p = clientFor(st.companies[0]);
        if (p) { st.clientId = p.id; st.company = p.tally.company; } else st.company = st.companies[0];
      }
    } catch (e) { if (!quiet) { st.error = e.message; st.status = ''; } }
    render();
  }
  // GSTR-1 / IFF autopilot (the CA Desk portal helper part of this extension): login → return → Prepare offline → upload JSON → Generate summary
  function uploadG1() {
    const c = client();
    if (!c || !c.gstin) return App.toast('Choose the client (with its GSTIN) first');
    if (!c.portal.username) return App.toast('Save the client’s GST ID and password on the Clients tab first');
    if (st.from !== st.to) return App.toast('Upload works for one month at a time – set From and To to the same month and build the JSON again');
    const [y, m] = st.from.split('-').map(Number);
    const ret = ($('#w-g1ret') && $('#w-g1ret').value) || 'GSTR1';
    const fy = m >= 4 ? `${y}-${String((y + 1) % 100).padStart(2, '0')}` : `${y - 1}-${String(y % 100).padStart(2, '0')}`;
    const quarter = m >= 4 ? Math.ceil((m - 3) / 3) : 4;
    const fp = `${String(m).padStart(2, '0')}${y}`;
    const names = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const job = { cid: '', key: '', gstin: c.gstin, ret, fp, fy, quarter, month: m, periodLabel: `${names[m - 1]} ${y}`, json: JSON.stringify(st.gstr1.json), jsonName: `${ret}_${c.gstin}_${fp}.json` };
    chrome.runtime.sendMessage({ type: 'start-g1', clientId: c.id, job }, (r) => {
      void chrome.runtime.lastError;
      if (!r || r.error) return App.toast((r && r.error) || 'Could not start the autopilot', 6000);
      App.toast('GST portal opened – type the CAPTCHA and log in. The autopilot uploads the JSON and generates the summary.', 7000);
    });
  }

  function addClientFromTally() {
    const name = st.company; if (!name) return;
    const p = G.newProfile(/\bLLP\b/i.test(name) ? 'llp' : /\bPUBLIC\b/i.test(name) ? 'public_company' : /\b(PVT|PRIVATE|LTD|LIMITED)\b/i.test(name) ? 'pvt_company' : 'proprietorship');
    p.status = 'registered'; p.nickname = name; p.partA.legalName = name; p.tally.company = name;
    App.profiles.push(p); App.saveProfiles();
    st.clientId = p.id; saveSettings();
    App.toast(`Added “${name}” as a client – add its GSTIN on the Clients tab`);
    render();
  }

  async function readJsonFiles(files) {
    const out = [];
    for (const f of files) { try { out.push({ name: f.name, json: JSON.parse(await f.text()) }); } catch (e) { App.toast(`${f.name} is not valid JSON`); } }
    return out;
  }
  async function load2B(files) {
    const got = await readJsonFiles(files);
    if (!got.length) return;
    const parsed = got.map(g => W.parse2B(g.json));
    const c = client();
    const wrong = parsed.find(p => p.gstin && c && c.gstin && p.gstin !== c.gstin);
    if (wrong && !confirm(`This 2B is for ${wrong.gstin}, but the client is ${c.gstin}. Use it anyway?`)) return;
    st.twoB = { gstin: parsed[0].gstin, docs: parsed.flatMap(p => p.docs) };
    st.twoBFiles = got.map(g => g.name);
    st.recon2b = null;
    App.toast(`Loaded ${st.twoB.docs.length} documents from GSTR-2B`);
    render();
  }
  async function loadR1(files) {
    const got = await readJsonFiles(files);
    if (!got.length) return;
    st.r1 = W.parseGSTR1(got[0].json);
    st.r1File = got[0].name;
    st.reconR1 = null;
    App.toast(`Loaded ${st.r1.docs.length} invoices/notes from GSTR-1`);
    render();
  }
  function dropZone(zoneSel, inputSel, handler) {
    const z = $(zoneSel), i = $(inputSel);
    if (!z || !i) return;
    z.addEventListener('click', () => i.click());
    i.addEventListener('change', () => { handler(Array.from(i.files)); i.value = ''; });
    z.addEventListener('dragover', (e) => { e.preventDefault(); z.classList.add('over'); });
    z.addEventListener('dragleave', () => z.classList.remove('over'));
    z.addEventListener('drop', (e) => { e.preventDefault(); z.classList.remove('over'); handler(Array.from(e.dataTransfer.files)); });
  }
  function downloadJson(name, obj) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(obj)], { type: 'application/json' }));
    a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 3000);
  }

  function wire() {
    const on = (sel, ev, fn) => { const e = $(sel); if (e) e.addEventListener(ev, fn); };
    on('#w-client', 'change', (e) => {
      const v = e.target.value;
      if (v.startsWith('tally:')) { st.clientId = ''; st.company = v.slice(6); }
      else { st.clientId = v; const c = client(); st.company = (c && c.tally.company) || ''; }
      st.docs = null; st.twoB = null; st.twoBFiles = []; st.r1 = null; st.r1File = ''; st.status = ''; st.error = '';
      saveSettings(); render();
    });
    on('#w-company', 'input', (e) => { st.company = e.target.value; });
    on('#w-port', 'change', (e) => { st.port = +e.target.value.replace(/\D/g, '') || 9000; saveSettings(); });
    on('#w-from', 'change', (e) => { st.from = e.target.value; if (st.to < st.from) st.to = st.from; render(); });
    on('#w-to', 'change', (e) => { st.to = e.target.value; render(); });
    on('#w-tol', 'change', (e) => { st.tolerance = +e.target.value || 0; saveSettings(); });
    on('#w-list', 'click', () => listCompanies(false));
    on('#w-addclient', 'click', addClientFromTally);
    on('#w-link', 'click', () => { const v = $('#w-linkto') && $('#w-linkto').value; if (v) linkTo(v); else App.toast('Choose the client first'); });
    on('#w-fromca', 'click', () => chrome.tabs.create({ url: 'https://smishra724.github.io/ca-desk/#gstdesk=' + encodeURIComponent(st.company) }));
    on('#w-fetch', 'click', fetchTally);
    on('#w-reg', 'click', () => XLSXW.save(`Registers_${fileBase()}.xlsx`, W.registers(st.docs)));
    on('#w-r1', 'click', () => {
      const c = client();
      if (!c || !c.gstin) { App.toast('Add the client GSTIN first'); return; }
      const [y, m] = st.from.split('-');
      st.gstr1 = W.buildGSTR1(st.docs, { gstin: c.gstin, fp: `${m}${y}` });
      render();
    });
    on('#w-g1up', 'click', uploadG1);
    on('#w-pickco', 'change', (e) => { st.company = e.target.value; const c = client(); if (c && st.company && (!c.tally.company || score(c, c.tally.company) < 0.35)) { c.tally.company = st.company; App.saveProfiles(); } st.docs = null; st.status = ''; saveSettings(); render(); });
    on('#w-relink', 'click', () => { const c = client(); if (c) { c.tally.company = st.company; App.saveProfiles(); App.toast('Linked'); render(); } });
    on('#w-raw', 'click', () => { if (!st.raw) return; const b = new Blob([JSON.stringify({ company: st.company, from: st.from, to: st.to, replies: st.raw }, null, 1)], { type: 'application/json' }); const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = `tally-reply-${fileBase()}.json`; a.click(); });
    on('#w-r1dl', 'click', () => { const c = client(); const [y, m] = st.from.split('-'); downloadJson(`GSTR1_${c.gstin}_${m}${y}.json`, st.gstr1.json); });
    on('#w-r1x', 'click', () => XLSXW.save(`GSTR1_exceptions_${fileBase()}.xlsx`, [{ name: 'Exceptions', rows: [['Date', 'Voucher no.', 'Party', 'GSTIN', 'Issue'],
      ...st.gstr1.exceptions.map(e => [e.doc.date || '', e.doc.number || '', e.doc.party || '', e.doc.gstin || '', e.msg])] }]));
    dropZone('#w-2b-drop', '#w-2b', load2B);
    dropZone('#w-r1-drop', '#w-r1f', loadR1);
    on('#w-rec2b', 'click', () => {
      const books = st.docs.filter(d => !d.cancelled && (d.kind === 'purchase' || d.kind === 'debit') && !d.rcm);
      st.recon2b = W.reconcile(books, st.twoB.docs.filter(p => p.section === 'B2B' || p.section === 'B2BA' || p.section === 'CDNR' || p.section === 'CDNRA' || p.section === 'ECOM'), { side: 'purchase', tolerance: st.tolerance });
      render();
    });
    on('#w-rec2bx', 'click', () => XLSXW.save(`2B_reconciliation_${fileBase()}.xlsx`, W.reconSheets(st.recon2b, 'purchase')));
    on('#w-recr1', 'click', () => {
      const own = ((client() || {}).gstin || '').slice(0, 2);
      const books = st.docs.filter(d => !d.cancelled && !d.export && (d.kind === 'sales' || d.kind === 'credit') && (d.gstin || (d.kind === 'sales' && d.pos !== own && d.total > 100000)));
      st.reconR1 = W.reconcile(books, st.r1.docs, { side: 'sales', tolerance: st.tolerance });
      render();
    });
    on('#w-recr1x', 'click', () => XLSXW.save(`GSTR1_reconciliation_${fileBase()}.xlsx`, W.reconSheets(st.reconR1, 'sales')));
    on('#w-3b', 'click', () => { st.threeB = W.threeB(st.docs, st.twoB, (client() || {}).gstin); render(); });
    on('#w-3bx', 'click', () => XLSXW.save(`GSTR3B_working_${fileBase()}.xlsx`, W.threeBSheet(st.threeB, st.twoB)));
  }

  // Clients sent from CA Desk (or added elsewhere) show up here straight away
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'local' && ch[G.KEYS.profiles] && ready && !$('#view-work')?.hidden) setTimeout(render, 80);
  });
  let ready = false;
  document.addEventListener('gstf-view', async (e) => {
    if (e.detail !== 'work') return;
    if (!ready) { await loadSettings(); ready = true; }
    render();
    listCompanies(true);   // show the companies open in Tally right away (quietly, if Tally is closed)
  });
})();
